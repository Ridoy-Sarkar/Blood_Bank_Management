<footer>
    <p>&copy; Blood Bank Management System. All rights reserved.</p>
</footer>