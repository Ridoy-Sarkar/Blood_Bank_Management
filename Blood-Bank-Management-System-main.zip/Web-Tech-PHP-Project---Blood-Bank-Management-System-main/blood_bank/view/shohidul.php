<center>
    <H2>Welcome</H2>
    <fieldset>
        <legend>
            <h3>Developer Shohidul</h3>
        </legend>
        <h3> Md. Shohidul Islam </h3>
        <p> Welcome to my profile! I am Md. Shohidul Islam, a dedicated student pursuing my B.Sc. in Computer Science
            and Engineering at American International University-Bangladesh. Cunrenly I live in Dhaka , Bangladesh <br>
            Email : <b> sojibaiub203@gmail.com </b><br>
            Mobile :<b> 01908903443<br>
                <br><a href="https://github.com/Shohidul203">Github</a><br>
                <br>



        </p>
        <a href="about.php">BACK</a>
    </fieldset>
</center>