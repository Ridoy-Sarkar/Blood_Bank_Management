<center>
    <H2>Welcome</H2>
    <fieldset>
        <legend>
            <h3> contract your recipient</h3>
        </legend>
        <h3></h3>
        <br><a href=" logout.php">LOG OUT</a><br>
    </fieldset>
</center>