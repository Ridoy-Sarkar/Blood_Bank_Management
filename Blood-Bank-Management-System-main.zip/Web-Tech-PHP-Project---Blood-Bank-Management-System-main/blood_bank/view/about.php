<center>
    <H2>Know Our Developer Team</H2>
    <fieldset>
        <legend>
            <h3>Developer</h3>
        </legend>
        <a href="shohidul.php">MD. SHOHIDUL ISLAM</a><br>
        <br><a href="avizit.php">AVIZIT ROY</a><br>
        <br><a href="ridoy.php">MD. RIDOY SARKAR</a><br>
        <br><a href="home.php">HOME</a>
    </fieldset>
</center>