<center>
    <H2>Welcome</H2>
    <fieldset>
        <legend>
            <h3>Developer Ridoy</h3>
        </legend>
        <h3> Ridoy Sarkar </h3>
        <p> Welcome to my profile! I am Md. Ridoy Sarkar, a dedicated student pursuing my B.Sc. in Computer Science
            and Engineering at American International University-Bangladesh. Cunrenly I live in Dhaka , Bangladesh <br>
            Email : <b> ridoysarkar@gmail.com </b><br>
            Mobile :<b> 01842313120<br>
                <br><a href="https://github.com/Ridoy-Sarkar">Github</a><br>
                <br>


        </p>
        <a href="about.php">BACK</a>
    </fieldset>
</center>