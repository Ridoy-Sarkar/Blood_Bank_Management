<center>
    <H2>Welcome</H2>
    <fieldset>
        <legend>
            <h3>Developer Avizit</h3>
        </legend>
        <h3> Avizit Roy </h3>
        <p> Welcome to my profile! I am Avizit Roy, a dedicated student pursuing my B.Sc. in Computer Science
            and Engineering at American International University-Bangladesh. Cunrenly I live in Dhaka , Bangladesh <br>
            Email : <b> avizitroybd@gmail.com </b><br>
            Mobile : <b>01732993693<br>
                <a href="https://github.com/avizitRX">Github</a><br>
                <br>
        </p>
        <a href="about.php">BACK</a>
    </fieldset>
</center>