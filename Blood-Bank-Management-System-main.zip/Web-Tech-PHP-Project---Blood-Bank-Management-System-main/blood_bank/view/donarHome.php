<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Donar Home</title>
</head>

<body>
    <section>


        <table border="0" width="100%">
            <tr>
                <td width="25%"></td>
                <td>
                    <table border="0" width="100%">
                        <tr>
                            <td width="70%" style="text-align: center">
                                <form>
                                    <h1>Welcome To Your Home</h1>
                                    <fieldset>
                                        <legend><b>
                                                <h3>LOG IN SUCCESSFULLY</h3>
                                            </b></legend>

                                        <a href="personal_information.php">PERSONAL INFORMATION</a><br>
                                        <br><a href="showBloodRequest.php">SHOW BLOOD REQUEST</a><br>
                                        <br><a href="findDonor.php">FIND BLOOD DONER</a><br>
                                        <br><a href=" logout.php">LOG OUT</a><br>
                                    </fieldset>
                                </form>
                            </td>
                        </tr>
                    </table>
                </td>
                <td width="25%"></td>
            </tr>
        </table>
    </section>


</body>

</html>