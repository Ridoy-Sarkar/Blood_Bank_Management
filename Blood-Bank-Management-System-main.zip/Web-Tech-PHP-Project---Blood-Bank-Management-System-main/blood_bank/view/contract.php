<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contract</title>
</head>

<body>
    <center>
        <H2>Welcome to contract list</H2>
        <fieldset>
            <legend>
                <h3>Blood Bank Of Some Hospital</h3>
            </legend>
            <h3> United Hospital Limited</h3>
            <p> Location: Gulshan, Dhaka <br>
                Contact: +880-2-88360001 <br>
                <a
                    href="https://www.google.com/maps/place/United+Hospital+Limited/@23.8046453,90.4131765,17z/data=!4m14!1m7!3m6!1s0x3755c7abd941ed15:0xf151df4e4e9c047c!2sUnited+Hospital+Limited!8m2!3d23.8046453!4d90.4157514!16s%2Fg%2F11h6q4v0ch!3m5!1s0x3755c7abd941ed15:0xf151df4e4e9c047c!8m2!3d23.8046453!4d90.4157514!16s%2Fg%2F11h6q4v0ch?entry=ttu">Google
                    Maps</a>

            </p>

            <h3>Apollo Hospitals Dhaka</h3>
            <p>Location: Bashundhara R/A, Dhaka <br>
                Contact: +880-2-55037242<br>
                <a
                    href="https://www.google.com/maps/dir//Plot+81,+Block-E,+Evercare+Hospital+Dhaka,+Bashundhara+Rd,+Dhaka+1229/@23.8102657,90.4128678,15z/data=!4m8!4m7!1m0!1m5!1m1!1s0x3755c64aaa9e9039:0x226faca86a7e028d!2m2!1d90.4313219!2d23.8102668?entry=ttu">Google
                    Maps</a>
            </p>

            <h3>Square Hospitals Ltd</h3>
            <p> Location: Panthapath, Dhaka <br>
                Contact: +880-2-8159457 <br>
                <a
                    href="https://www.google.com/maps/place/Square+Hospitals+Ltd./@23.7528446,90.3455114,14z/data=!4m10!1m2!2m1!1sSquare+Hospitals+Ltd!3m6!1s0x3755b8ae4e52eabd:0x113b1873c9a9c2c1!8m2!3d23.7528438!4d90.3815598!15sChRTcXVhcmUgSG9zcGl0YWxzIEx0ZFoWIhRzcXVhcmUgaG9zcGl0YWxzIGx0ZJIBCGhvc3BpdGFs4AEA!16s%2Fg%2F11fmgy9g_1?entry=ttu">Google
                    Maps</a>



            </p>

            <!-- <br><a href=" logout.php">LOG OUT</a> &nbsp;&nbsp; -->
            <a href="home.php">HOME</a>
        </fieldset>
    </center>

</body>

</html>